int j;
