﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntMapping
{
    partial class EntityMappingParser
    {
        public void Process()
        {
            this.prog();
        }
    }
}
